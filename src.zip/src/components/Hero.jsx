// // import React from "react";

// // const Hero = () => {
// //   return (
// //     <section className="h-screen flex flex-col justify-center items-center text-center px-6 white">
// //       {/* <h1 className="text-5xl font-bold mb-4 leading-tight">The Urban Electric Bike</h1>
// //       <p className="text-lg mb-6 max-w-xl text-gray-700">
// //         Cowboy is the new way to move through your city. Effortless. Elegant. Electric.
// //       </p> */}
// //       <h1>Go Dutch</h1>
// //       <button className="px-6 py-3 bg-black text-white rounded-full hover:scale-105 transition">Explore</button>
// //       <p>From €2,999   
// //       Book a free test ride</p>

// //       <p>Find My Bike</p>

// //         Theft Detection

// //             Custom AdaptivePower™

// //        Automatic assistance

// // Servicing Nearby

// // 200+ stores
// //     </section>
// //   );
// // };

// // export default Hero;











// // import React from "react";
// // import { ChevronRight } from "lucide-react"; // optional for the arrow
// // import {Godutch} from "../assets/Go dutch.png";

// // const Hero = () => {
// //   return (
// //     <section className="w-full bg-[#f9f5ef] px-10 py-20 flex flex-col lg:flex-row items-center justify-between gap-10">
// //       {/* Text Content */}
// //       <div className="flex flex-col gap-6 max-w-xl">
// //         <p className="text-sm text-gray-500">Cruiser</p>
// //         <h1 className="text-6xl font-semibold text-black">Go Dutch</h1>

// //         <div className="flex items-center gap-6">
// //           <button className="bg-black text-white px-6 py-3 rounded-full text-sm font-semibold hover:scale-105 transition">
// //             Explore
// //           </button>
// //           <span className="text-gray-800 text-sm">From €2,999</span>
// //           <a href="#" className="text-sm text-black hover:underline flex items-center gap-1">
// //             Book a free test ride <ChevronRight size={16} />
// //           </a>
// //         </div>

// //         {/* Feature List */}
// //         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
// //           <div>
// //             <p className="font-medium text-black">Find My Bike</p>
// //             <p>Theft Detection</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Custom AdaptivePower™</p>
// //             <p>Automatic assistance</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Servicing Nearby</p>
// //             <p>200+ stores</p>
// //           </div>
// //         </div>
// //       </div>

// //       {/* Bike Image (optional) */}
// //       <div className="w-full lg:w-1/2 flex justify-center">
// //         <img
// //           src={Godutch} // <- replace with your actual path
// //           alt="Cowboy Bike"
// //           className="max-w-md w-full"
// //         />
// //       </div>
// //     </section>
// //   );
// // };

// // export default Hero;








// // import React from "react";
// // import { ChevronRight } from "lucide-react";
// // // ✅ Import the image with a proper variable name and correct file path:
// // import Godutch from "../assets/GoDutch.png"; // make sure file is named `GoDutch.png`

// // const Hero = () => {
// //   return (
// //     <section className="w-full bg-[#f9f5ef] px-10 py-20 flex flex-col lg:flex-row items-center justify-between gap-10">
// //       {/* Text Content */}
// //       <div className="flex flex-col gap-6 max-w-xl">
// //         <p className="text-sm text-gray-500">Cruiser</p>
// //         <h1 className="text-6xl font-semibold text-black">Go Dutch</h1>

// //         <div className="flex items-center gap-6">
// //           <button className="bg-black text-white px-6 py-3 rounded-full text-sm font-semibold hover:scale-105 transition">
// //             Explore
// //           </button>
// //           <span className="text-gray-800 text-sm">From €2,999</span>
// //           <a href="#" className="text-sm text-black hover:underline flex items-center gap-1">
// //             Book a free test ride <ChevronRight size={16} />
// //           </a>
// //         </div>

// //         {/* Feature List */}
// //         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
// //           <div>
// //             <p className="font-medium text-black">Find My Bike</p>
// //             <p>Theft Detection</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Custom AdaptivePower™</p>
// //             <p>Automatic assistance</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Servicing Nearby</p>
// //             <p>200+ stores</p>
// //           </div>
// //         </div>
// //       </div>

// //       {/* Bike Image */}
// //       <div className="w-full lg:w-1/2 flex justify-center">
// //         <img
// //           src={Godutch}
// //           alt="Cowboy Bike"
// //           className="max-w-md w-full"
// //         />
// //       </div>
// //     </section>
// //   );
// // };

// // export default Hero;




// // import React from "react";
// // import { ChevronRight } from "lucide-react";
// // // ✅ Import the image with a proper variable name and correct file path:
// // import Godutch from "../assets/GoDutch.png"; // make sure file is named `GoDutch.png`

// // const Hero = () => {
// //   return (
// //     <section className="w-full bg-[#f9f5ef] px-10 py-20 flex flex-col lg:flex-row items-center justify-between gap-10">
// //       {/* Text Content */}
// //       <div className="flex flex-col gap-6 max-w-xl">
// //         <p className="text-sm text-gray-500">Cruiser</p>
// //         <h1 className="text-6xl font-semibold text-black">Go Dutch</h1>

// //         <div className="flex items-center gap-6">
// //           <button className="bg-black text-white px-6 py-3 rounded-full text-sm font-semibold hover:scale-105 transition">
// //             Explore
// //           </button>
// //           <span className="text-gray-800 text-sm">From €2,999</span>
// //           <a href="#" className="text-sm text-black hover:underline flex items-center gap-1">
// //             Book a free test ride <ChevronRight size={16} />
// //           </a>
// //         </div>

// //         {/* Feature List */}
// //         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
// //           <div>
// //             <p className="font-medium text-black">Find My Bike</p>
// //             <p>Theft Detection</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Custom AdaptivePower™</p>
// //             <p>Automatic assistance</p>
// //           </div>
// //           <div>
// //             <p className="font-medium text-black">Servicing Nearby</p>
// //             <p>200+ stores</p>
// //           </div>
// //         </div>
// //       </div>

// //       {/* Bike Image */}
// //       <div className="w-full lg:w-1/2 flex justify-center">
// //         <img
// //           src={Godutch}
// //           alt="Cowboy Bike"
// //           className="max-w-md w-full"
// //         />
// //       </div>
// //     </section>
// //   );
// // };

// // export default Hero;



// import React from "react";
// import { ChevronRight } from "lucide-react";
// import Godutch from "../assets/GoDutch.png"; // make sure file is named `GoDutch.png` and path is correct

// const Hero = () => {
//   return (
//     <section className="w-full bg-[#f9f5ef] px-10 py-20 flex flex-col lg:flex-row items-center justify-between gap-10"> {/* Restored original background color */}
//       {/* Text Content */}
//       <div className="flex flex-col gap-6 max-w-xl text-left"> {/* Kept text-left adjustment */}
//         <p className="text-lg font-medium text-gray-700 mb-2">Cruiser</p> {/* Kept font size and color adjustments */}
//         <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8"> {/* Kept font sizes and weights adjustments */}
//           Go Dutch
//         </h1>

//         <div className="flex items-center space-x-4 mb-12"> {/* Kept gap and mb-12 adjustments */}
//           <button className="bg-black text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-800 transition duration-300"> {/* Kept button styling adjustments */}
//             Explore
//           </button>
//           <p className="text-xl font-medium">From €2,999</p> {/* Kept font size and weight adjustments */}
//           <a href="#" className="text-lg text-black hover:underline flex items-center space-x-1"> {/* Kept font size and spacing */}
//             Book a free test ride <ChevronRight size={20} /> {/* Kept ChevronRight size adjustment */}
//           </a>
//         </div>

//         {/* Feature List */}
//         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
//           <div className="text-left"> {/* Kept text-left adjustment */}
//             <p className="font-semibold">Find My Bike</p> {/* Kept font weight adjustment */}
//             <p>Theft Detection</p>
//           </div>
//           <div className="text-left"> {/* Kept text-left adjustment */}
//             <p className="font-semibold">Custom AdaptivePower™</p> {/* Kept font weight adjustment */}
//             <p>Automatic assistance</p>
//           </div>
//           <div className="text-left"> {/* Kept text-left adjustment */}
//             <p className="font-semibold">Servicing Nearby</p> {/* Kept font weight adjustment */}
//             <p>200+ stores</p>
//           </div>
//         </div>
//       </div>

//       {/* Bike Image */}
//       <div className="w-full lg:w-1/2 flex justify-center">
//         <img
//           src={Godutch}
//           alt="Cowboy Bike"
//           className="max-w-md w-full object-contain" // Kept object-contain
//         />
//       </div>
//     </section>
//   );
// };

// export default Hero;





// import React from "react";
// import { ChevronRight } from "lucide-react";
// import Godutch from "../assets/GoDutch.png";

// const Hero = () => {
//   return (
//     <section className="w-full min-h-screen flex flex-col lg:flex-row items-center justify-between gap-10 px-10 py-20 bg-gradient-to-r from-[#f9f5ef] to-[#ececec]">
      
//       {/* Text Content */}
//       <div className="flex flex-col gap-6 max-w-xl text-left">
//         <p className="text-lg font-medium text-gray-700 mb-2">Cruiser</p>
//         <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8">
//           Go Dutch
//         </h1>

//         <div className="flex items-center space-x-4 mb-12">
//           <button className="bg-black text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-800 transition duration-300">
//             Explore
//           </button>
//           <p className="text-xl font-medium">From €2,999</p>
//           <a href="#" className="text-lg text-black hover:underline flex items-center space-x-1">
//             Book a free test ride <ChevronRight size={20} />
//           </a>
//         </div>

//         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
//           <div>
//             <p className="font-semibold">Find My Bike</p>
//             <p>Theft Detection</p>
//           </div>
//           <div>
//             <p className="font-semibold">Custom AdaptivePower™</p>
//             <p>Automatic assistance</p>
//           </div>
//           <div>
//             <p className="font-semibold">Servicing Nearby</p>
//             <p>200+ stores</p>
//           </div>
//         </div>
//       </div>

//       {/* Bike Image */}
//       <div className="w-full lg:w-1/2 flex justify-center">
//         <img
//           src={Godutch}
//           alt="Cowboy Bike"
//           className="max-h-[500px] w-auto object-contain"
//         />
//       </div>
//     </section>
//   );
// };

// export default Hero;





// import React from "react";
// import { ChevronRight } from "lucide-react";
// import Godutch from "../assets/GoDutch.png";

// const Hero = () => {
//   return (
//     <section className="w-full min-h-screen flex flex-col lg:flex-row items-center justify-between gap-10 px-10 py-20 bg-[linear-gradient(to_right,#f9f5ef,#f3eede)]">
      
//       {/* Text Content */}
//       <div className="flex flex-col gap-6 max-w-xl text-left">
//         <p className="text-lg font-medium text-gray-700 mb-2">Cruiser</p>
//         <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8">
//           Go Dutch
//         </h1>

//         <div className="flex items-center space-x-4 mb-12">
//           <button className="bg-black text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-800 transition duration-300">
//             Explore
//           </button>
//           <p className="text-xl font-medium">From €2,999</p>
//           <a href="#" className="text-lg text-black hover:underline flex items-center space-x-1">
//             Book a free test ride <ChevronRight size={20} />
//           </a>
//         </div>

//         <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
//           <div>
//             <p className="font-semibold">Find My Bike</p>
//             <p>Theft Detection</p>
//           </div>
//           <div>
//             <p className="font-semibold">Custom AdaptivePower™</p>
//             <p>Automatic assistance</p>
//           </div>
//           <div>
//             <p className="font-semibold">Servicing Nearby</p>
//             <p>200+ stores</p>
//           </div>
//         </div>
//       </div>

//       {/* Bike Image */}
//       <div className="w-full lg:w-1/2 flex justify-center">
//         <img
//           src={Godutch}
//           alt="Cowboy Bike"
//           className="max-h-[500px] w-auto object-contain"
//         />
//       </div>
//     </section>
//   );
// };

// export default Hero;




import React from "react";
import { ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import Godutch from "../assets/GoDutch.png";

const Hero = () => {
  return (
    <section className="w-full min-h-screen flex flex-col lg:flex-row items-center justify-between gap-10 px-10 py-20 bg-[linear-gradient(to_right,#f9f5ef,#f3eede)]">
      
      {/* Text Content */}
      <motion.div
        className="flex flex-col gap-6 max-w-xl text-left"
        initial={{ opacity: 0, y: 50 }}  // from below
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8 }}
      >
        <p className="text-lg font-medium text-gray-700 mb-2">Cruiser</p>
        <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8">
          Go Dutch
        </h1>

        <div className="flex items-center space-x-4 mb-12">
          <button className="bg-black text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-800 transition duration-300">
            Explore
          </button>
          <p className="text-xl font-medium">From €2,999</p>
          <a href="#" className="text-lg text-black hover:underline flex items-center space-x-1">
            Book a free test ride <ChevronRight size={20} />
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t mt-8 text-sm text-gray-700">
          <div>
            <p className="font-semibold">Find My Bike</p>
            <p>Theft Detection</p>
          </div>
          <div>
            <p className="font-semibold">Custom AdaptivePower™</p>
            <p>Automatic assistance</p>
          </div>
          <div>
            <p className="font-semibold">Servicing Nearby</p>
            <p>200+ stores</p>
          </div>
        </div>
      </motion.div>

      {/* Bike Image */}
      <motion.div
        className="w-full lg:w-1/2 flex justify-center"
        initial={{ opacity: 0, y: 50 }}  // from below
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.8 }}
      >
        <img
          src={Godutch}
          alt="Cowboy Bike"
          className="max-h-[500px] w-auto object-contain"
        />
      </motion.div>
    </section>
  );
};

export default Hero;
